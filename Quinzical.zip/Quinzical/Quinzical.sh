#!/bin/bash
java -jar --module-path /home/se2062020/javafx-sdk-11.0.2/lib --add-modules javafx.controls,javafx.media,javafx.base,javafx.fxml Quinzical.jar
exit
