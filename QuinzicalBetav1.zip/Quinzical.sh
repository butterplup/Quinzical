#!/bin/bash
java -jar --module-path /usr/share/java/lib --add-modules javafx.controls,javafx.media,javafx.base,javafx.fxml Quinzical.jar
exit
